1. Layout utama aplikasi adalah portrait.Layout tidak responsive sehingga membuka aplikasi dengan mode landscape akan merusak layout keseluruhan.
2. Untuk memutar lagu dan melakukan pause dapat dilakukan dengan 2 tombol yang sudah disediakan.
3. Untuk keluar dari menu about dapat dilakukan dengan menekan tombol back pada HP (Tidak disediakan tombol back pada aplikasi).
4. Lyric tidak dapat discroll secara manual oleh user.